package com.example.mvvmretrofit.retrofit;

import static com.example.mvvmretrofit.constant.AppConstant.API_KEY;
import com.example.mvvmretrofit.response.ArticleResponse;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiRequest {
    @GET ("top-headlines?source=techcrunch&apiKey=" + API_KEY)
    Call<ArticleResponse>getTopHeadLines();

}
