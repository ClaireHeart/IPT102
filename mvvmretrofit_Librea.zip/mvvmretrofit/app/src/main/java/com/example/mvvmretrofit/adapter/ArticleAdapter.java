package com.example.mvvmretrofit.adapter;

public class ArticleAdapter {
}
